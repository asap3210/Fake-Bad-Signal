package com.asap3210.troublecall

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import java.nio.ByteOrder

/** Decodifica un MP3 de res/raw a PCM mono 16-bit al ritmo pedido (para el ejemplo de 8 s). */
object Decoder {
    fun decode(ctx: Context, rawName: String, targetRate: Int, seconds: Int): ShortArray {
        val id = ctx.resources.getIdentifier(rawName, "raw", ctx.packageName)
        if (id == 0) return ShortArray(0)
        val ex = MediaExtractor()
        var codec: MediaCodec? = null
        try {
            ctx.resources.openRawResourceFd(id).use { ex.setDataSource(it.fileDescriptor, it.startOffset, it.length) }
            ex.selectTrack(0)
            val fmt = ex.getTrackFormat(0)
            var srcRate = fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            var ch = fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
            codec = MediaCodec.createDecoderByType(fmt.getString(MediaFormat.KEY_MIME)!!)
            codec.configure(fmt, null, null, 0)
            codec.start()

            val chunks = ArrayList<ShortArray>()
            var frames = 0
            val info = MediaCodec.BufferInfo()
            var inDone = false
            var outDone = false
            while (!outDone && frames < srcRate * seconds) {
                if (!inDone) {
                    val i = codec.dequeueInputBuffer(10_000)
                    if (i >= 0) {
                        val buf = codec.getInputBuffer(i)!!
                        val n = ex.readSampleData(buf, 0)
                        if (n < 0) {
                            codec.queueInputBuffer(i, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inDone = true
                        } else {
                            codec.queueInputBuffer(i, 0, n, ex.sampleTime, 0)
                            ex.advance()
                        }
                    }
                }
                val o = codec.dequeueOutputBuffer(info, 10_000)
                if (o >= 0) {
                    val ob = codec.getOutputBuffer(o)!!
                    ob.position(info.offset)
                    ob.limit(info.offset + info.size)
                    val sb = ob.order(ByteOrder.nativeOrder()).asShortBuffer()
                    val tmp = ShortArray(sb.remaining())
                    sb.get(tmp)
                    val mono = ShortArray(tmp.size / ch) { tmp[it * ch] }
                    chunks.add(mono)
                    frames += mono.size
                    codec.releaseOutputBuffer(o, false)
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outDone = true
                } else if (o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val of = codec.outputFormat
                    srcRate = of.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                    ch = of.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                }
            }
            val src = ShortArray(frames)
            var p = 0
            for (c in chunks) { c.copyInto(src, p); p += c.size }
            if (src.isEmpty()) return src
            val outLen = (src.size.toLong() * targetRate / srcRate).toInt()
            return ShortArray(outLen) { src[(it.toLong() * srcRate / targetRate).toInt().coerceAtMost(src.size - 1)] }
        } catch (e: Exception) {
            return ShortArray(0)
        } finally {
            try { codec?.stop() } catch (_: Exception) {}
            codec?.release()
            ex.release()
        }
    }
}
