package com.asap3210.troublecall

import android.Manifest
import android.app.role.RoleManager
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    private var permsOk by mutableStateOf(false)
    private var roleOk by mutableStateOf(false)
    private var testEffect: CallEffect? = null

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            permsOk = hasPerms()
        }
    private val roleLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            roleOk = hasRole()
        }

    private fun neededPerms() = buildList {
        add(Manifest.permission.READ_CONTACTS)
        add(Manifest.permission.READ_PHONE_STATE)
        add(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
    }

    private fun hasPerms() = neededPerms().all {
        checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED
    }

    private fun hasRole() =
        getSystemService(RoleManager::class.java).isRoleHeld(RoleManager.ROLE_CALL_SCREENING)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        permsOk = hasPerms()
        roleOk = hasRole()
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(Modifier.fillMaxSize()) { Screen() }
            }
        }
    }

    override fun onDestroy() {
        testEffect?.stop()
        super.onDestroy()
    }

    @Composable
    private fun Screen() {
        var contacts by remember { mutableStateOf(emptyList<Contact>()) }
        var selected by remember { mutableStateOf(Prefs.selected(this)) }
        var query by remember { mutableStateOf("") }
        var auto by remember { mutableStateOf(Prefs.auto(this)) }
        var noise by remember { mutableStateOf(Prefs.noise(this)) }
        var intensity by remember { mutableFloatStateOf(Prefs.intensity(this)) }
        var testing by remember { mutableStateOf(false) }
        var previewMsg by remember { mutableStateOf("") }
        var previewBusy by remember { mutableStateOf(false) }

        LaunchedEffect(permsOk) { if (permsOk) contacts = Contacts.load(this@MainActivity) }

        Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Trouble Call", style = MaterialTheme.typography.headlineMedium)

            if (!permsOk) {
                Button(onClick = { permLauncher.launch(neededPerms().toTypedArray()) }, Modifier.fillMaxWidth()) {
                    Text("1. Conceder permisos (contactos y llamadas)")
                }
            }
            if (!roleOk) {
                Button(
                    onClick = {
                        val rm = getSystemService(RoleManager::class.java)
                        roleLauncher.launch(rm.createRequestRoleIntent(RoleManager.ROLE_CALL_SCREENING))
                    },
                    Modifier.fillMaxWidth()
                ) { Text("2. Permitir detectar con quién llamas") }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Activar automáticamente")
                    Text("Solo en llamadas con los contactos marcados", style = MaterialTheme.typography.bodySmall)
                }
                Switch(checked = auto, onCheckedChange = { auto = it; Prefs.setAuto(this@MainActivity, it) })
            }

            Text("Intensidad: ${(intensity * 100).toInt()}%")
            Slider(
                value = intensity,
                onValueChange = { intensity = it; Prefs.setIntensity(this@MainActivity, it) }
            )

            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Añadir ruido por el altavoz")
                    Text("Solo se oye si la llamada está en altavoz", style = MaterialTheme.typography.bodySmall)
                }
                Switch(checked = noise, onCheckedChange = { noise = it; Prefs.setNoise(this@MainActivity, it) })
            }

            Button(
                enabled = permsOk && !previewBusy,
                onClick = {
                    previewBusy = true
                    Preview.run(this@MainActivity, intensity, noise) { msg, done ->
                        previewMsg = msg
                        if (done) previewBusy = false
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Escuchar cómo me oirán (ejemplo de 8 s)") }
            if (previewMsg.isNotEmpty()) Text(previewMsg, style = MaterialTheme.typography.bodySmall)

            OutlinedButton(
                onClick = {
                    if (testing) { testEffect?.stop(); testEffect = null }
                    else testEffect = CallEffect(this@MainActivity).also { it.start() }
                    testing = !testing
                },
                Modifier.fillMaxWidth()
            ) { Text(if (testing) "Detener prueba manual" else "Probar ahora (en una llamada)") }

            OutlinedTextField(
                value = query, onValueChange = { query = it },
                label = { Text("Buscar contacto") }, singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Text("Con estos contactos te oirán entrecortado (${selected.size}):",
                style = MaterialTheme.typography.titleSmall)

            val shown = contacts.filter {
                query.isBlank() || it.name.contains(query, true) || it.number.contains(query)
            }
            LazyColumn(Modifier.weight(1f)) {
                items(shown, key = { it.key }) { c ->
                    val on = c.key in selected
                    Row(
                        Modifier.fillMaxWidth().clickable {
                            selected = if (on) selected - c.key else selected + c.key
                            Prefs.setSelected(this@MainActivity, selected)
                        }.padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(checked = on, onCheckedChange = null)
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text(c.name)
                            Text(c.number, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        }
    }
}
