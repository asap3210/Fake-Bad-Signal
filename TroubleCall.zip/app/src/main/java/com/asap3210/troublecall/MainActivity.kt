package com.asap3210.troublecall

import android.media.AudioManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    private val engine = NoiseEngine()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(Modifier.fillMaxSize()) { Screen() }
            }
        }
    }

    override fun onDestroy() {
        engine.stop()
        super.onDestroy()
    }

    @OptIn(ExperimentalMaterial3Api::class)
    @Composable
    private fun Screen() {
        var active by remember { mutableStateOf(false) }
        var mode by remember { mutableStateOf(NoiseMode.MIXED) }
        var intensity by remember { mutableFloatStateOf(0.6f) }
        val audio = remember { getSystemService(AUDIO_SERVICE) as AudioManager }

        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("Trouble Call", style = MaterialTheme.typography.headlineLarge)
            Text(
                "Simula mala cobertura durante una llamada. Pon la llamada en altavoz " +
                    "y activa la interferencia: el micrófono la captará y la otra persona oirá cortes y ruido.",
                style = MaterialTheme.typography.bodyMedium
            )

            Text("Tipo de interferencia")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                NoiseMode.values().take(2).forEach { m ->
                    FilterChip(selected = mode == m, onClick = { mode = m; engine.mode = m }, label = { Text(m.label) })
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                NoiseMode.values().drop(2).forEach { m ->
                    FilterChip(selected = mode == m, onClick = { mode = m; engine.mode = m }, label = { Text(m.label) })
                }
            }

            Text("Intensidad: ${(intensity * 100).toInt()}%")
            Slider(value = intensity, onValueChange = { intensity = it; engine.intensity = it })

            Button(
                onClick = {
                    if (active) engine.stop() else {
                        audio.mode = AudioManager.MODE_IN_COMMUNICATION
                        engine.mode = mode; engine.intensity = intensity
                        engine.start()
                    }
                    active = !active
                },
                modifier = Modifier.fillMaxWidth().height(64.dp)
            ) { Text(if (active) "Detener interferencia" else "Iniciar interferencia") }

            OutlinedButton(
                onClick = { engine.burstNow() },
                enabled = active,
                modifier = Modifier.fillMaxWidth().height(56.dp)
            ) { Text("Corte de señal ahora") }

            Text(
                "Consejos: usa el volumen de llamada (botones laterales) para ajustar cuánto se oye, " +
                    "y acerca el altavoz al micrófono.",
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}
