# Trouble Call

App Android que simula problemas de señal (estática, crujidos, cortes entrecortados) durante una llamada.

## Cómo funciona
Android no permite a una app inyectar audio en una llamada normal sin root. Por eso la app reproduce
el ruido por el canal de voz: con la llamada **en altavoz**, el micrófono lo capta y la otra persona
lo oye como mala cobertura.

## Uso
1. Inicia la llamada y activa el altavoz.
2. Abre Trouble Call, elige tipo e intensidad y pulsa **Iniciar interferencia**.
3. Usa **Corte de señal ahora** para un corte puntual.

## Compilar
Abre en Android Studio, o `gradle :app:assembleDebug`. GitHub Actions también genera el APK.
