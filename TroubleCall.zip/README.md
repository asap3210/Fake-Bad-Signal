# Trouble Call

App Android que simula mala cobertura en las llamadas con los contactos que elijas.

## Qué hace
- Eliges contactos de tu agenda.
- Cuando llamas o te llama uno de ellos, la app corta tu micrófono a ráfagas aleatorias: esa persona te oye entrecortado.
- Opcional: ruido de estática por el altavoz (solo se capta con la llamada en altavoz).
- Botón de ejemplo: graba 8 s de tu voz y reproduce cómo te oirá el otro con la intensidad elegida.
- Sonido de fondo opcional: 16 grabaciones reales (mar, playa, gaviotas, lluvia, viento, río, bosque, ranas, hoguera, fuego, tráfico, tienda, granja, aire acondicionado, ritual, misterio) y 5 sintetizados en el móvil (cafetería, misa, aeropuerto, tenis, fútbol).

## Audios
Las grabaciones están en `app/src/main/res/raw/` (mono, 22 kHz, máx. 60 s, en bucle). Aportadas por el autor del proyecto; comprueba la licencia de cada una antes de publicar la app.
- Intensidad ajustable. Se desactiva sola al colgar.

## Configuración (una vez)
1. Conceder permisos de contactos y estado del teléfono.
2. Permitir "detectar con quién llamas" (rol de filtro de llamadas; la app nunca bloquea ni modifica llamadas).

## Limitaciones
Android no permite alterar el audio de una llamada sin root. El corte usa el silencio del micrófono del sistema, que en algunos móviles/versiones no tiene efecto. Probar primero con un amigo.

## Compilar
Android Studio, o `gradle :app:assembleDebug`. GitHub Actions genera el APK.
